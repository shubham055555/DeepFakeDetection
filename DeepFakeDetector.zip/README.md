# DeepFake Detector

Simple DeepFake detection app using Streamlit + TensorFlow.

## How to Run

1. Install dependencies:
    ```
    pip install -r requirements.txt
    ```

2. If model not found, train dummy model:
    ```
    python src/model_training.py
    ```

3. Run App:
    ```
    streamlit run app.py
    ```