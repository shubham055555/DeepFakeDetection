def load_images(folder_path):
    return []