import cv2
import numpy as np
from tensorflow.keras.models import load_model

class Predictor:
    def __init__(self, model_path):
        self.model = load_model(model_path)

    def predict_frame(self, frame):
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        img = cv2.resize(gray, (128, 128))
        img = img / 255.0
        img = img.reshape(1, 128, 128, 1)
        pred = self.model.predict(img)[0][0]
        return pred

    def predict_video(self, video_path):
        cap = cv2.VideoCapture(video_path)
        fake_count = 0
        total_count = 0

        while True:
            ret, frame = cap.read()
            if not ret:
                break
            total_count += 1
            if self.predict_frame(frame) > 0.5:
                fake_count += 1

        cap.release()
        if total_count == 0:
            return 0
        return fake_count / total_count