import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), 'src')))

import streamlit as st
import numpy as np
import cv2

from predictor import Predictor

st.title("DeepFake Detection App 🔥")

model_path = "deepfake_model.h5"

if os.path.exists(model_path):
    predictor = Predictor(model_path)
else:
    st.error("Model not found! Please train and save the model first.")
    st.stop()

upload_type = st.radio("Choose Input Type:", ('Image', 'Video'))

if upload_type == 'Image':
    uploaded_file = st.file_uploader("Upload an Image", type=["jpg", "jpeg", "png"])
    if uploaded_file is not None:
        file_bytes = np.asarray(bytearray(uploaded_file.read()), dtype=np.uint8)
        opencv_image = cv2.imdecode(file_bytes, cv2.IMREAD_GRAYSCALE)
        img = cv2.resize(opencv_image, (128, 128))
        img = img / 255.0
        img = img.reshape(1, 128, 128, 1)

        st.image(opencv_image, caption='Uploaded Image.', use_column_width=True)
        prediction = predictor.model.predict(img)[0][0]
        if prediction > 0.5:
            st.error(f"Prediction: FAKE ({prediction:.2f}) 😱")
        else:
            st.success(f"Prediction: REAL ({prediction:.2f}) ✅")

elif upload_type == 'Video':
    uploaded_file = st.file_uploader("Upload a Video", type=["mp4", "avi", "mov"])
    if uploaded_file is not None:
        temp_video_path = "temp_video.mp4"
        with open(temp_video_path, "wb") as f:
            f.write(uploaded_file.read())

        fake_ratio = predictor.predict_video(temp_video_path)
        st.video(temp_video_path)

        if fake_ratio > 0.5:
            st.error(f"Video is FAKE! Fake Frames: {fake_ratio*100:.2f}%")
        else:
            st.success(f"Video is REAL! Fake Frames: {fake_ratio*100:.2f}%")

        os.remove(temp_video_path)